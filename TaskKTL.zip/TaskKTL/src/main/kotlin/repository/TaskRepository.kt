package repository

import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import data.Priority
import data.Task
import service.LocalDateTimeAdapter
import service.LoggerService
import java.io.File
import java.time.LocalDateTime

class TaskRepository {

    private val tasks = mutableListOf<Task>()
    private var nextId = 1

    fun addTask(
        title: String,
        description: String,
        priority: Priority
    ) {
        val task = Task(
            id = nextId++,
            title = title,
            description = description,
            priority = priority
        )

        tasks.add(task)
    }

    fun getAllTasks(): List<Task> {
        return tasks.toList()
    }

    fun getTaskById(id: Int): Task? {
        return tasks.find { it.id == id }
    }

    fun updateTask(
        id: Int,
        title: String?,
        description: String?,
        priority: Priority?,
        isDone: Boolean?
    ): Boolean {

        val task = getTaskById(id) ?: return false

        if (!title.isNullOrBlank()) {
            task.title = title
        }

        if (!description.isNullOrBlank()) {
            task.description = description
        }

        if (priority != null) {
            task.priority = priority
        }

        if (isDone != null) {
            task.isDone = isDone
        }

        return true
    }

    fun deleteTask(id: Int): Boolean {
        return tasks.removeIf { it.id == id }
    }

    fun findByTitle(title: String): List<Task> {
        return tasks.filter {
            it.title.contains(title, ignoreCase = true)
        }
    }

    fun findByPriority(priority: Priority): List<Task> {
        return tasks.filter {
            it.priority == priority
        }
    }

    fun findByStatus(isDone: Boolean): List<Task> {
        return tasks.filter {
            it.isDone == isDone
        }
    }

    fun search(
        title: String?,
        priority: Priority?,
        isDone: Boolean?
    ): List<Task> {

        return tasks.filter { task ->

            (title.isNullOrBlank()
                    || task.title.contains(title, true))

                    &&

                    (priority == null
                            || task.priority == priority)

                    &&

                    (isDone == null
                            || task.isDone == isDone)
        }
    }

    fun markTasksDone(ids: List<Int>) {

        ids.forEach { id ->

            tasks.find { it.id == id }?.let {
                it.isDone = true
            }
        }
    }

    fun sortByTitle(
        ascending: Boolean
    ): List<Task> {

        return if (ascending) {
            tasks.sortedBy { it.title }
        } else {
            tasks.sortedByDescending { it.title }
        }
    }

    fun sortByPriority(
        ascending: Boolean
    ): List<Task> {

        return if (ascending) {
            tasks.sortedBy { it.priority.level }
        } else {
            tasks.sortedByDescending {
                it.priority.level
            }
        }
    }

    fun sortByDate(
        ascending: Boolean
    ): List<Task> {

        return if (ascending) {
            tasks.sortedBy { it.createdAt }
        } else {
            tasks.sortedByDescending {
                it.createdAt
            }
        }
    }

    fun saveToFile(fileName: String) {

        try {

            val gson = GsonBuilder()
                .registerTypeAdapter(
                    LocalDateTime::class.java,
                    LocalDateTimeAdapter()
                )
                .setPrettyPrinting()
                .create()

            File(fileName)
                .writeText(
                    gson.toJson(tasks)
                )

        } catch (e: Exception) {

            LoggerService.logError(
                e.message ?: "Save error"
            )

            println("Ошибка сохранения")
        }
    }

    fun loadFromFile(fileName: String) {

        try {

            val file = File(fileName)

            if (!file.exists()) {

                println("Файл не найден")
                return
            }

            val gson = GsonBuilder()
                .registerTypeAdapter(
                    LocalDateTime::class.java,
                    LocalDateTimeAdapter()
                )
                .create()

            val type =
                object : TypeToken<List<Task>>() {}
                    .type

            val loadedTasks: List<Task> =
                gson.fromJson(
                    file.readText(),
                    type
                )

            tasks.clear()
            tasks.addAll(loadedTasks)

            nextId =
                (tasks.maxOfOrNull {
                    it.id
                } ?: 0) + 1

        } catch (e: Exception) {

            LoggerService.logError(
                e.message ?: "Load error"
            )

            println("Ошибка загрузки")
        }
    }
}