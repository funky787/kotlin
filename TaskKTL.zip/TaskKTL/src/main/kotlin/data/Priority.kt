package data

enum class Priority(val level: Int) {

    LOW(1),
    MEDIUM(2),
    HIGH(3),
    VERY_HIGH(4),
    CRITICAL(5);

    companion object {

        fun fromInt(value: Int): Priority? {
            return entries.find { it.level == value }
        }
    }
}