package menu

import data.Priority
import data.Task
import repository.TaskRepository

class MenuController(
    private val repository: TaskRepository
) {

    fun start() {

        while (true) {

            printMenu()

            when (readlnOrNull()?.toIntOrNull()) {

                1 -> createTask()

                2 -> showTasks(
                    repository.getAllTasks()
                )

                3 -> searchTask()

                4 -> editTask()

                5 -> deleteTask()

                6 -> sortTasks()

                7 -> saveTasks()

                8 -> loadTasks()

                9 -> markMultipleTasks()

                0 -> {
                    println("До свидания!")
                    return
                }

                else -> println("Некорректный ввод")
            }
        }
    }

    private fun printMenu() {

        println(
            """
            
1 — Создать задачу
2 — Показать все задачи
3 — Найти задачу
4 — Редактировать задачу
5 — Удалить задачу
6 — Сортировка
7 — Сохранить в файл
8 — Загрузить из файла
9 — Отметить несколько задач выполненными
0 — Выход

            """.trimIndent()
        )
    }

    private fun createTask() {

        println("Название:")
        val title = readln()

        println("Описание:")
        val description = readln()

        val priority = readPriority()

        repository.addTask(
            title,
            description,
            priority
        )

        println("Задача создана")
    }

    private fun showTasks(tasks: List<Task>) {

        if (tasks.isEmpty()) {
            println("Список задач пуст")
            return
        }

        println(
            "%-5s %-20s %-10s %-10s %-25s"
                .format(
                    "ID",
                    "Title",
                    "Priority",
                    "Done",
                    "CreatedAt"
                )
        )

        println("-".repeat(80))

        tasks.forEach {

            println(
                "%-5d %-20s %-10d %-10s %-25s"
                    .format(
                        it.id,
                        it.title,
                        it.priority.level,
                        if (it.isDone) "Yes" else "No",
                        it.createdAt
                    )
            )
        }
    }

    private fun searchTask() {

        println("Название (Enter - пропустить):")
        val title =
            readln().ifBlank { "" }

        println("Приоритет (1-5 или Enter):")
        val priorityInput = readln()

        val priority =
            if (priorityInput.isBlank())
                null
            else
                Priority.fromInt(
                    priorityInput.toIntOrNull() ?: 0
                )

        println("Статус y/n или Enter:")
        val statusInput = readln()

        val status =
            when (statusInput.lowercase()) {
                "y" -> true
                "n" -> false
                else -> null
            }

        val result =
            repository.search(
                title,
                priority,
                status
            )

        showTasks(result)
    }

    private fun editTask() {

        println("Введите ID задачи:")

        val id =
            readln().toIntOrNull()

        if (id == null) {
            println("Некорректный ID")
            return
        }

        val task =
            repository.getTaskById(id)

        if (task == null) {
            println("Задача не найдена")
            return
        }

        println(
            "Новое название (Enter оставить старое):"
        )
        val title = readln()

        println(
            "Новое описание (Enter оставить старое):"
        )
        val description = readln()

        println(
            "Новый приоритет (1-5 или Enter):"
        )
        val priorityInput = readln()

        val priority =
            if (priorityInput.isBlank())
                null
            else
                Priority.fromInt(
                    priorityInput.toIntOrNull() ?: 0
                )

        println(
            "Выполнена? y/n или Enter:"
        )
        val doneInput = readln()

        val done =
            when (doneInput.lowercase()) {
                "y" -> true
                "n" -> false
                else -> null
            }

        repository.updateTask(
            id,
            title,
            description,
            priority,
            done
        )

        println("Задача обновлена")
    }

    private fun deleteTask() {

        println("Введите ID:")

        val id =
            readln().toIntOrNull()

        if (id == null) {
            println("Некорректный ID")
            return
        }

        println(
            "Вы уверены, что хотите удалить? (y/n)"
        )

        val answer = readln()

        if (answer.lowercase() != "y") {
            println("Удаление отменено")
            return
        }

        if (repository.deleteTask(id))
            println("Удалено")
        else
            println("Задача не найдена")
    }

    private fun sortTasks() {

        println(
            """
1 - По названию
2 - По приоритету
3 - По дате создания
            """.trimIndent()
        )

        val sortType =
            readln().toIntOrNull()

        if (sortType == null) {
            println("Ошибка")
            return
        }

        println(
            """
1 - По возрастанию
2 - По убыванию
            """.trimIndent()
        )

        val ascending =
            readln() == "1"

        val result =
            when (sortType) {

                1 ->
                    repository.sortByTitle(
                        ascending
                    )

                2 ->
                    repository.sortByPriority(
                        ascending
                    )

                3 ->
                    repository.sortByDate(
                        ascending
                    )

                else -> {
                    println("Ошибка")
                    return
                }
            }

        showTasks(result)
    }

    private fun saveTasks() {

        println("Имя файла:")

        val fileName = readln()

        repository.saveToFile(fileName)

        println("Сохранено")
    }

    private fun loadTasks() {

        println("Имя файла:")

        val fileName = readln()

        repository.loadFromFile(fileName)

        println("Загружено")
    }

    private fun markMultipleTasks() {

        println(
            "Введите ID через запятую:"
        )

        val ids =
            readln()
                .split(",")
                .mapNotNull {
                    it.trim()
                        .toIntOrNull()
                }

        repository.markTasksDone(ids)

        println("Задачи обновлены")
    }

    private fun readPriority(): Priority {

        while (true) {

            println(
                "Введите приоритет (1-5):"
            )

            val value =
                readln().toIntOrNull()

            val priority =
                value?.let {
                    Priority.fromInt(it)
                }

            if (priority != null)
                return priority

            println(
                "Введите число от 1 до 5"
            )
        }
    }
}