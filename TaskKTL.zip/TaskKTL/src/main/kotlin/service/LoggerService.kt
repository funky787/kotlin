package service

import java.io.File
import java.time.LocalDateTime

object LoggerService {

    private const val LOG_FILE = "errors.log"

    fun logError(message: String) {

        try {

            File(LOG_FILE).appendText(
                "${LocalDateTime.now()} - $message\n"
            )

        } catch (_: Exception) {
        }
    }
}