package org.sadovodBase

import menu.MenuController
import repository.TaskRepository

fun main() {

    val repository = TaskRepository()

    val menu =
        MenuController(repository)

    menu.start()
}